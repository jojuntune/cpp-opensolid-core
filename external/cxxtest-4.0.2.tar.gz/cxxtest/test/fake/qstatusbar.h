// fake qstatusbar.h

class QStatusBar
{
public:
    QStatusBar( void * ) {}
    void setProgress()  {}
    void addWidget( void *, int ) {}
    void removeWidget( void * ) {}
};
